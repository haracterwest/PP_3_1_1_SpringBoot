package com.example.crudboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
